function sayHello() {
  alert("ยินดีต้อนรับสู่เว็บไซต์ของฉัน!");
}